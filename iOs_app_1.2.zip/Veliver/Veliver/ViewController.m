//
//  ViewController.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//



#import "ViewController.h"
#import "CleaningCell.h"
#import "CleaningAboutVc.h"
#import "WorkList.h"

@interface ViewController ()

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:@"Уборка" image:[UIImage imageNamed:@"cleaning.png"] tag:0];
        self.tabBarItem = item;
        
        NSString *path = [[NSBundle mainBundle]pathForResource:@"cleaningList" ofType:@"plist"];
        _cleanigList = [NSArray arrayWithContentsOfFile:path];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title.png"]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
    [self setTable:nil];
    [super viewDidUnload];
}

#pragma mark - Helpers

- (void)configureCell:(CleaningCell*)cell forRow:(NSInteger)row
{
    cell.separator.hidden = NO;
    if (row == self.cleanigList.count-1)
        cell.separator.hidden = YES;
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.cleanigList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cleaningCellIdentifier = @"CleaningCell";
    
    CleaningCell *cell = (CleaningCell *)[tableView dequeueReusableCellWithIdentifier:cleaningCellIdentifier];
    
    if (cell == nil)
    {
        NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:cleaningCellIdentifier owner:self options:nil];
        cell = [nibs objectAtIndex:0];
    }
    
    [self configureCell:cell forRow:indexPath.row];
    
    NSDictionary *cleaning = [NSDictionary dictionaryWithDictionary:_cleanigList[indexPath.row]];
    
    cell.title.text = [cleaning valueForKey:@"title"];
    cell.ico.image = [UIImage imageNamed:[cleaning valueForKey:@"ico"]];
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *cleaning = [NSDictionary dictionaryWithDictionary:self.cleanigList[indexPath.row]];
    if ([[cleaning objectForKey:@"id"] isEqualToNumber:@(0)])
    {
        WorkList *workList = [[WorkList alloc] initWithNibName:nil bundle:nil];
        [self.navigationController pushViewController:workList animated:YES];
    }
    else
    {
        CleaningAboutVc *cleaningAboutVc = [[CleaningAboutVc alloc] initWithNibName:nil bundle:nil cleaning:cleaning];
        [self.navigationController pushViewController:cleaningAboutVc animated:YES];
    }
}

@end
