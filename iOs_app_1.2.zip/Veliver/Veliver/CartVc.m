//
//  CartVc.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 22.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "CartVc.h"
#import "Cart.h"
#import "CartCell.h"
#import "HistoryCell.h"
#import "OfferVc.h"
#import "HistoryController.h"

@interface CartVc ()
{
    NSArray *historyCart;
    BOOL hasOffice;
    int sum;
}
@end

@implementation CartVc

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Корзина";
        
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:@"Корзина" image:[UIImage imageNamed:@"cart"] tag:4];
        self.tabBarItem = item;
//        historyCart = [[Cart sharedInstance] loadOrderHistory];
        _items = [[Cart sharedInstance] items];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reload:) name:@"UpdateCart" object:nil];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title.png"]];
    
    if (_items.count > 0)
        [self.tabBarController.tabBar.items[4] setBadgeValue:[NSString stringWithFormat:@"%lu", (unsigned long)_items.count]];
    else
    {
        [self.tabBarController.tabBar.items[4] setBadgeValue:nil];
        hasOffice = NO;
    }
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self reload:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Helpers
- (void)reload:(NSNotification *)notification
{
    if (notification != nil)
        _items = notification.object;
    
    NSLog(@"%@", _items);
    
    _table.frame = CGRectMake(0, _table.frame.origin.y, _table.frame.size.width, _items.count *52 + (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0") ? 0.0 : 0.0));
    
    _resultGroup.frame = CGRectMake(0, _table.frame.origin.y + _table.frame.size.height, 320,  _resultGroup.frame.size.height);
    _content.contentSize = CGSizeMake(320, _resultGroup.frame.origin.y + _resultGroup.frame.size.height);
    
    historyCart = [[Cart sharedInstance] loadOrderHistory];
    
    if (historyCart.count > 0)
    {
        _historyGroup.hidden = NO;
        [_historyController loadHistory];
        [_historyTable reloadData];
        [_historyTable setFrame:CGRectMake(_historyTable.frame.origin.x, _historyTable.frame.origin.y, _historyTable.frame.size.width, _historyTable.contentSize.height)];
        [_historyGroup setFrame:CGRectMake(_historyGroup.frame.origin.x, _historyGroup.frame.origin.y, _historyGroup.frame.size.width, 123+_historyTable.frame.origin.y)];
        if (_items.count == 0)
        {
            NSLog(@"!!");
            
     
            int baseOrignGroup = 202;
            int availableHeight = self.view.frame.size.height - baseOrignGroup -(SYSTEM_VERSION_LESS_THAN(@"7.0") ? 0 : 113);
         
            int offset=0;
            if(availableHeight > _historyTable.contentSize.height+_historyTable.frame.origin.y)
            {
                offset = availableHeight  - (_historyTable.contentSize.height+_historyTable.frame.origin.y);
            }
            
            _historyGroup.frame = CGRectMake(_historyGroup.frame.origin.x,
                                             baseOrignGroup+offset,
                                             _historyGroup.frame.size.width,
                                             _historyGroup.frame.size.height);
            NSLog(@"%f", _historyGroup.frame.origin.y);
        }
        else
        {
             int availableHeight = self.view.frame.size.height - (_resultGroup.frame.origin.y + _resultGroup.frame.size.height) -(SYSTEM_VERSION_LESS_THAN(@"7.0") ? 0 : 113);
            int offset=0;
            if(availableHeight > _historyTable.contentSize.height+_historyTable.frame.origin.y)
            {
                offset = availableHeight  - (_historyTable.contentSize.height+_historyTable.frame.origin.y);
            }
            
            _historyGroup.frame = CGRectMake(_historyGroup.frame.origin.x,
                                             _resultGroup.frame.origin.y + _resultGroup.frame.size.height+offset,
                                             _historyGroup.frame.size.width,
                                             _historyGroup.frame.size.height);
            NSLog(@"%f", _historyGroup.frame.origin.y);
            
        }
         [_historyGroup setFrame:CGRectMake(_historyGroup.frame.origin.x, _historyGroup.frame.origin.y, _historyGroup.frame.size.width, _historyTable.contentSize.height+_historyTable.frame.origin.y)];
        [_content setContentSize:CGSizeMake(self.view.bounds.size.width, _historyGroup.frame.origin.y+_historyTable.contentSize.height+_historyTable.frame.origin.y)];
    }
    else if (historyCart.count == 0) {
        _historyGroup.hidden = YES;
    }
    
    sum = 0;
    for (NSDictionary *item in _items) {
        if ([item objectForKey:@"price"])
            sum += [[item objectForKey:@"price"] intValue];
        else
        {
            hasOffice = YES;
        }
    }
    
    if (_items.count > 0)
        [self.tabBarController.tabBar.items[4] setBadgeValue:[NSString stringWithFormat:@"%lu", (unsigned long)_items.count]];
    else
    {
        [self.tabBarController.tabBar.items[4] setBadgeValue:nil];
        hasOffice = NO;
    }

    if (sum != 0 || hasOffice)
    {
        _result.text = [NSString stringWithFormat:@"%i руб.", (int)(sum - sum*0.1f)];
        _resultGroup.hidden = NO;
        _empty.hidden = YES;
    }
    else
    {
        _empty.hidden = NO;
        _resultGroup.hidden = YES;
        _empty.frame = CGRectMake(0, IS_IPHONE_5 ? 144 : 100, 320, _empty.frame.size.height);
    }
    
    [_table reloadData];
}


- (IBAction)offer:(id)sender
{
    if ((sum - sum*0.1) < 1460 && !hasOffice)
    {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка!" message:@"Минимальный заказ составляет\n1460 рублей" delegate:nil cancelButtonTitle:@"Ок" otherButtonTitles:nil] show];
        return;
    }
    OfferVc *offerVc = [[OfferVc alloc] initWithItems:_items andSumm:sum];
    [self.navigationController pushViewController:offerVc animated:YES];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"CartCell";
    CartCell *cell = (CartCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
    {
        NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:cellIdentifier owner:self options:nil];
        cell = [nibs objectAtIndex:0];
    }
    cell.title.text = [_items[indexPath.row] objectForKey:@"title"];
    
    if ([_items[indexPath.row] objectForKey:@"workArea"] != nil)
    {
        cell.count.text = [NSString stringWithFormat:@"(%@ %@)",
                           [_items[indexPath.row] objectForKey:@"workArea"],
                           [_items[indexPath.row] objectForKey:@"ei"]];
        cell.count.hidden = NO;
        cell.title.frame = CGRectMake(cell.title.frame.origin.x, 6, cell.title.frame.size.width, cell.title.frame.size.height);
    }
    else
    {
        cell.title.frame = CGRectMake(cell.title.frame.origin.x, 13, cell.title.frame.size.width, cell.title.frame.size.height);
        cell.count.hidden = YES;
    }
    if ([_items[indexPath.row] objectForKey:@"price"] != nil)
    {
        cell.price.text = [NSString stringWithFormat:@"%@ р.", [[_items[indexPath.row] objectForKey:@"price"] stringValue]];
        cell.price.hidden = NO;
    }
    else
    {
        cell.price.hidden = YES;
    }
    cell.item = _items[indexPath.row];
    
    return cell;
}

#pragma mark - UITableViewDelegate



@end
