//
//  AppDelegate.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;
@class AdditionalServicesVc;
@class CartVc;
@class WindowVc;
@class ContactsVc;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *cleaningViewController;
@property (strong, nonatomic) AdditionalServicesVc *additionalServicesVc;
@property (strong, nonatomic) WindowVc *windowVc;
@property (strong, nonatomic) CartVc *cartVc;
@property (strong, nonatomic) ContactsVc *contactsVc;

@property (strong, nonatomic) UITabBarController *tabBarController;

@end
