//
//  HistoryController.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 20.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HistoryController : NSObject <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSArray *hItems;

- (void)loadHistory;

@end
