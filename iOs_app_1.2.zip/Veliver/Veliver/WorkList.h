//
//  WorkList.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 30.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WorkList : UIViewController
@property (weak, nonatomic) IBOutlet UIScrollView *content;
@property (weak, nonatomic) IBOutlet UIImageView *contentImage;

@end
