//
//  Window.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 01.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WindowVc : UIViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIScrollView *content;
@property (weak, nonatomic) IBOutlet UITextField *w1;
@property (weak, nonatomic) IBOutlet UITextField *w2;
@property (weak, nonatomic) IBOutlet UITextField *w3;
@property (weak, nonatomic) IBOutlet UITextField *w4;
@property (weak, nonatomic) IBOutlet UITextField *w5;
@property (weak, nonatomic) IBOutlet UILabel *result;

- (IBAction)calulate:(id)sender;
- (IBAction)add2Cart:(id)sender;

@end
