//
//  OfferVc.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 02.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface OfferVc : UIViewController <UITextFieldDelegate, UIPickerViewDelegate, MFMailComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *fio;
@property (weak, nonatomic) IBOutlet UITextField *address;
@property (weak, nonatomic) IBOutlet UITextField *date;
@property (weak, nonatomic) IBOutlet UITextField *time;
@property (weak, nonatomic) IBOutlet UITextField *phone;

@property (weak, nonatomic) IBOutlet UILabel *summ;
@property (weak, nonatomic) IBOutlet UIDatePicker *timePicker;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (weak, nonatomic) IBOutlet UIScrollView *content;
@property (nonatomic) NSDictionary *historyRecords;

- (IBAction)send:(UIButton *)sender;
- (IBAction)timeChange:(UIDatePicker *)sender;
- (IBAction)dateChange:(UIDatePicker *)sender;
- (id)initWithItems:(NSArray *)items andSumm:(int)summ;
-(id)initWithItems:(NSArray *)items andSumm:(int)summ fromHistoryRecords:(NSDictionary*)dictinary;
@end
