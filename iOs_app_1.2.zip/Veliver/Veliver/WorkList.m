//
//  WorkList.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 30.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "WorkList.h"

@interface WorkList ()

@end

@implementation WorkList

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title.png"]];
    _content.contentSize = CGSizeMake(320, _contentImage.frame.size.height+12);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
