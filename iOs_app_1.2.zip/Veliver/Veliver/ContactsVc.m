//
//  ContactsVc.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 02.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "ContactsVc.h"
#import "NSDictionary+QueryString.h"

@interface ContactsVc ()
{
    CGPoint currentOffset;
}
@end

@implementation ContactsVc

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"О нас";
        
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:@"О нас" image:[UIImage imageNamed:@"contacts.png"] tag:3];
        self.tabBarItem = item;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title.png"]];
    _textView.layer.contents = (id)[UIImage imageNamed:@"textEdit"].CGImage;
    _content.contentSize = CGSizeMake(320, 750);
    [self configureKeyBouard];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)configureKeyBouard
{
    UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    toolBar.tintColor = [UIColor colorWithRed:0.56f
                                        green:0.59f
                                         blue:0.63f
                                        alpha:1.0f];
    toolBar.translucent = YES;
    

    toolBar.items = @[
                      [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                      [[UIBarButtonItem alloc] initWithTitle:@"Готово"
                                                       style:UIBarButtonItemStyleDone
                                                      target:self
                                                      action:@selector(done)]
                      ];
    _textView.inputAccessoryView = toolBar;
}

#pragma mark Actions

- (IBAction)go2site:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.veliver.ru"]];
}

- (IBAction)callNumber:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel:+74957830626"]];
}

- (IBAction)sendReview:(UIButton *)sender
{
    if (_textView.text.length == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка!" message:@"Заполните текст отзыва" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        return;
    }
    [_textView resignFirstResponder];
    [_content setContentOffset:currentOffset animated:YES];
    _content.scrollEnabled = YES;
    NSString *message = _textView.text;
    
    NSDictionary *params =  @{@"message" : message,
                              @"review" : @"1"};//[NSDictionary dictionaryWithObject:message forKey:@"message"];
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"iosmail.php%@", [params queryString]] relativeToURL:[NSURL URLWithString:@"http://www.veliver.ru/"]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    [NSURLConnection sendAsynchronousRequest:request queue:[[NSOperationQueue alloc] init] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        NSLog(@"%@", [NSString stringWithUTF8String:[data bytes]]);
        dispatch_async(dispatch_get_main_queue(), ^{
            sender.enabled = YES;
            if (connectionError == nil)
            {
                [[[UIAlertView alloc] initWithTitle:@"Спасибо!"
                                            message:@"Ваш отзыв отправлен"
                                           delegate:self
                                  cancelButtonTitle:@"Ok"
                                  otherButtonTitles:nil] show];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"Cart"];
            }
            else
            {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка!"
                                            message:@"Что-то пошло не так, пожалуйста, попробуйте повторить позже"
                                           delegate:nil
                                  cancelButtonTitle:@"Ok"
                                  otherButtonTitles:nil] show];
            }
        });
    }];
    
    
//    if ([MFMailComposeViewController canSendMail])
//    {
//        MFMailComposeViewController *mailCompose = [[MFMailComposeViewController alloc] init];
//        mailCompose.mailComposeDelegate = self;
//        [mailCompose setSubject:@"Отзыв из iOS приложения Veliver"];
//        [mailCompose setToRecipients:SERVICE_EMAILS];
//        [mailCompose setMessageBody:[NSString stringWithFormat:@"<b>Отзыв:</b><br>%@", _textView.text] isHTML:YES];
//        [self presentModalViewController:mailCompose animated:YES];
//    }
//    else
//    {
//        [[[UIAlertView alloc] initWithTitle:@"Ошибка!" message:@"Настройте почту на телефоне. Настройки -> Почта -> Добавить учетную запись" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
//    }
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
    if (!error)
    {
        [[[UIAlertView alloc] initWithTitle:@"Спасибо!" message:@"Ваш отзыв отправлен" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
    }
}

- (void)done
{
    [_textView resignFirstResponder];
    [_content setContentOffset:currentOffset animated:YES];
    _content.scrollEnabled = YES;
}



#pragma mark UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    currentOffset = _content.contentOffset;
    [_content setContentOffset:CGPointMake(0, _textView.frame.origin.y - 10 - (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0") ? 64 : 0)) animated:YES];
    _content.scrollEnabled = NO;
}


@end
