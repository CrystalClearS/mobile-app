//
//  Cart.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 22.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "Cart.h"

@implementation Cart

+ (Cart*)sharedInstance
{
    static dispatch_once_t once;
    static id sharedInstance;
    dispatch_once(&once, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
        NSArray *savedItems = [[NSUserDefaults standardUserDefaults] objectForKey:@"Cart"];
        if (savedItems.count > 0)
        {
            _items = [savedItems mutableCopy];
        }
        else
        {
            _items = [NSMutableArray new];
        }
    }
    return self;
}

- (BOOL)add2Cart:(NSDictionary *)item
{
    if (![_items containsObject:item])
    {
        [_items addObject:item];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateCart" object:_items];
        [[NSUserDefaults standardUserDefaults] setObject:_items forKey:@"Cart"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NSString *title = [item[@"title"] stringByReplacingOccurrencesOfString:@"(часов)" withString:@""];
        title = [title stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSString *message = [NSString stringWithFormat:@"Добавлено в корзину: \"%@\"", title];
        [[[UIAlertView alloc] initWithTitle:@"Корзина" message:message delegate:nil cancelButtonTitle:@"Ок" otherButtonTitles: nil] show];
        
        return YES;
    }
    return NO;
}

- (BOOL)addItems2Cart:(NSArray *)items
{
    BOOL result = false;
    for (id item in items) {
        if (![_items containsObject:item]) {
            result = true;
            [_items addObject:item];
        }
    }
    if (result) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateCart" object:_items];
        [[NSUserDefaults standardUserDefaults] setObject:_items forKey:@"Cart"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    return result;
}

- (void)deleteItem:(NSDictionary *)item
{
    [_items removeObject:item];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateCart" object:_items];
    [[NSUserDefaults standardUserDefaults] setObject:_items forKey:@"Cart"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
- (void)deleteItemFromHistory:(NSDictionary *)item
{
    NSMutableArray *savedRecordsInHistory =[[[NSUserDefaults standardUserDefaults] objectForKey:@"history"] mutableCopy];
    if([savedRecordsInHistory count] > 0)
    {
        [savedRecordsInHistory removeObject:item];
         [[NSUserDefaults standardUserDefaults] setObject:savedRecordsInHistory forKey:@"history"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateCart" object:_items];
    }
}
- (void)clearCart
{
    [_items removeAllObjects];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateCart" object:_items];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)saveCart:(NSArray *)cart client:(NSDictionary *)client summa:(NSString *)summa
{
    NSMutableArray *history = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults]
                                                              objectForKey:@"history"]];
    [history addObject:@{@"cart" : cart,
                         @"client" : client,
                         @"summa" : summa,
                         @"date" : [client objectForKey:@"date"]}];
    [[NSUserDefaults standardUserDefaults] setObject:history forKey:@"history"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSArray *)loadOrderHistory
{
    return [NSArray arrayWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:@"history"]];
}

@end
