//
//  HistoryController.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 20.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "HistoryController.h"
#import "Cart.h"
#import "HistoryCell.h"
#import "HistoryDetailsVC.h"
#import "AppDelegate.h"
@implementation HistoryController

- (id)init
{
    self = [super init];
    if (self)
    {
        [self loadHistory];
    }
    return self;
}

- (void)loadHistory
{
    _hItems = [[Cart sharedInstance] loadOrderHistory];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _hItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"HC ROW");
    static NSString *cellIdentifier = @"HistoryCell";
    HistoryCell *cell = (HistoryCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
    {
        NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:cellIdentifier owner:self options:nil];
        cell = [nibs objectAtIndex:0];
    }
    
    int sum = [[_hItems[indexPath.row] objectForKey:@"summa"] intValue];
    cell.price.text = [NSString stringWithFormat:@"%i р.", (int)(sum - sum*0.1)];
//    NSDate *date = [_hItems[indexPath.row] objectForKey:@"date"];
  //  NSDateFormatter *formater = [NSDateFormatter new];
//    formater.dateFormat = @"dd.MM.yyyy";
    cell.date.text = [_hItems[indexPath.row] objectForKey:@"date"];//[formater stringFromDate:date];
    return cell;
}


#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%@",_hItems[indexPath.row]);
    HistoryDetailsVC *vc = [[HistoryDetailsVC alloc]initWithItemes:_hItems[indexPath.row]];
    AppDelegate *delegate =(AppDelegate *)[[UIApplication sharedApplication] delegate];    dispatch_async(dispatch_get_main_queue(),
    ^{
        NSLog(@"%@",delegate.tabBarController.selectedViewController);
        [(UINavigationController *)delegate.tabBarController.selectedViewController pushViewController:vc animated:YES];
    });
}
@end
