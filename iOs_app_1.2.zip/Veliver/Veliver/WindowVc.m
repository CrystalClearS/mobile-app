//
//  Window.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 01.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "WindowVc.h"
#import "Cart.h"

@interface WindowVc ()
{
    CGPoint currentOffset;
    BOOL isOffset;
    BOOL isKeyboardSown;
    NSArray *windowList;
    NSMutableArray *workList;
    int v1, v2, v3, v4, v5, summ;
}
@end

@implementation WindowVc

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Мойка окон";
        
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:@"Мойка окон" image:[UIImage imageNamed:@"window.png"] tag:1];
        self.tabBarItem = item;
        
        NSString *path = [[NSBundle mainBundle]pathForResource:@"window" ofType:@"plist"];
        windowList = [NSArray arrayWithContentsOfFile:path];
        workList = [NSMutableArray new];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title.png"]];
    _content.alwaysBounceVertical = NO;
    _content.showsVerticalScrollIndicator = NO;
    _content.contentSize = CGSizeMake(320, 436);
    _content.clipsToBounds = NO;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShowNotification:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHideNotification:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)keyboardWillShowNotification:(NSNotification *)note
{
    if (isKeyboardSown) { return; }
    NSDictionary *userInfo = note.userInfo;
    CGRect keyboardSize = ((NSValue *)userInfo[UIKeyboardFrameEndUserInfoKey]).CGRectValue;
    double animationDuration = ((NSNumber *)userInfo[UIKeyboardAnimationDurationUserInfoKey]).doubleValue;
    UIViewAnimationCurve curveAnimation = ((NSNumber *)userInfo[UIKeyboardAnimationCurveUserInfoKey]).integerValue;
    
    [UIView animateWithDuration:animationDuration delay:0 options:curveAnimation << 16 animations:^{
        CGRect frame = _content.frame;
        frame.size.height -= keyboardSize.size.height;
        _content.frame = frame;
    } completion:^(BOOL finished) {
        isKeyboardSown = YES;
    }];
}

- (void)keyboardWillHideNotification:(NSNotification *)note
{
    if (!isKeyboardSown) { return; }
    NSDictionary *userInfo = note.userInfo;
    CGRect keyboardSize = ((NSValue *)userInfo[UIKeyboardFrameEndUserInfoKey]).CGRectValue;
    double animationDuration = ((NSNumber *)userInfo[UIKeyboardAnimationDurationUserInfoKey]).doubleValue;
    UIViewAnimationCurve curveAnimation = ((NSNumber *)userInfo[UIKeyboardAnimationCurveUserInfoKey]).integerValue;
    
    [UIView animateWithDuration:animationDuration delay:0 options:curveAnimation << 16 animations:^{
        CGRect frame = _content.frame;
        frame.size.height += keyboardSize.size.height;
        _content.frame = frame;
    } completion:^(BOOL finished) {
        isKeyboardSown = NO;
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Actions

- (IBAction)calulate:(id)sender
{
//    v1 = [_w1.text intValue];
    v2 = [_w2.text intValue];
    v3 = [_w3.text intValue];
    v4 = [_w4.text intValue];
    v5 = [_w5.text intValue];
    
    summ = 0;
    [workList removeAllObjects];
    
//    summ += v1 * [[windowList[0] objectForKey:@"price"] intValue];
    summ += v2 * [[windowList[0] objectForKey:@"price"] intValue];
    summ += v3 * [[windowList[1] objectForKey:@"price"] intValue];
    summ += v4 * [[windowList[2] objectForKey:@"price"] intValue];
    summ += v5 * [[windowList[3] objectForKey:@"price"] intValue];
    _result.text = [NSString stringWithFormat:@"%i руб.", summ];
    
//    if (v1 > 0)
//    {
//        [workList addObject:@{@"title": [windowList[0] objectForKey:@"title"], @"workArea" : [NSNumber numberWithInt:v1], @"ie" : @"шт"}];
//    }
    if (v2 > 0)
    {
        [workList addObject:@{@"title": [windowList[0] objectForKey:@"title"], @"workArea" : [NSNumber numberWithInt:v2], @"ie" : @"шт"}];
    }
    if (v3 > 0)
    {
        [workList addObject:@{@"title": [windowList[1] objectForKey:@"title"], @"workArea" : [NSNumber numberWithInt:v3], @"ie" : @"шт"}];
    }
    if (v4 > 0)
    {
        [workList addObject:@{@"title": [windowList[2] objectForKey:@"title"], @"workArea" : [NSNumber numberWithInt:v4], @"ie" : @"м2"}];
    }
    if (v5 > 0)
    {
        [workList addObject:@{@"title": [windowList[3] objectForKey:@"title"], @"workArea" : [NSNumber numberWithInt:v5], @"ie" : @"шт"}];
    }
}

- (IBAction)add2Cart:(id)sender
{
    [self calulate:nil];
    
    [[Cart sharedInstance] add2Cart:@{
                                      @"title": @"Мойка окон",
                                      @"price": @(summ),
                                      @"work" : workList
                                      }];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    int iValue;
    if (string.length != 0 && ![[NSScanner scannerWithString:string] scanInt:&iValue])
    {
        return NO;
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    textField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 4, 35)];
    textField.leftViewMode = UITextFieldViewModeAlways;
    /*if (!isOffset)
    {
        currentOffset = _content.contentOffset;
        isOffset = YES;
    }
    [_content setContentOffset:CGPointMake(0, textField.superview.frame.origin.y-(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0") ? 66 : 0)) animated:YES];
     */
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
//    [_content  setContentOffset:currentOffset animated:YES];
    isOffset = NO;
    return YES;
}

@end
