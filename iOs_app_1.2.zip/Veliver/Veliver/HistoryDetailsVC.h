//
//  HistoryDetailsVC.h
//  Veliver
//
//  Created by Aleksey Maltsev on 13.12.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryDetailsVC : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UIScrollView *content;
@property (weak, nonatomic) IBOutlet UIView *resultGroup;
@property (weak, nonatomic) IBOutlet UILabel *result;
@property (nonatomic) NSMutableArray *items;
@property (nonatomic) NSDictionary *sourceRecord;
- (IBAction)removeButtonTouch:(id)sender;
- (IBAction)repeatOrderButtonTouch:(id)sender;
- (id)initWithItemes:(NSDictionary *)itemsArary;
@end
