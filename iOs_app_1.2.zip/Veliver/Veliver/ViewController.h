//
//  ViewController.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *table;
@property (nonatomic) NSArray *cleanigList;

@end
