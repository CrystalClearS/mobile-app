//
//  CleaningAboutVc.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "CleaningAboutVc.h"
#import "Cart.h"

@interface CleaningAboutVc ()
{
    CGPoint currentContentOffset;
    BOOL isCompanyCleaner;
    NSDictionary *price;
}
@end

@implementation CleaningAboutVc

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil cleaning:(NSDictionary *)cleaning
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _cleaning = cleaning;
        price = [cleaning objectForKey:@"price"];
        self.title = [_cleaning valueForKey:@"title"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    
    UISwipeGestureRecognizer *gesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipe:)];
    [self.view addGestureRecognizer:gesture];
    [self configureContent];
}

#pragma mark - Helpers

- (void)configureContent
{
    _image.image = [UIImage imageNamed:[_cleaning valueForKey:@"image"]];
    
    NSString *about = [_cleaning valueForKey:@"about"];
    
    CGSize aboutSize = [about sizeWithFont:_about.font constrainedToSize:CGSizeMake(308, 2000) lineBreakMode:NSLineBreakByWordWrapping];
    
    _about.frame = CGRectMake(_about.frame.origin.x,
                              _about.frame.origin.y,
                              _about.frame.size.width,
                              aboutSize.height+20);
    
    _about.text = [_cleaning valueForKey:@"about"];
    
    _workArea.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 4, 32)];
    _workArea.leftViewMode = UITextFieldViewModeAlways;
    _workArea.rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, 32)];
    _workArea.rightViewMode = UITextFieldViewModeAlways;
    
    if ([[_cleaning objectForKey:@"id"] intValue] == 6)
    {
        _officeButton.frame = CGRectMake(_officeButton.frame.origin.x, _about.frame.origin.y + _about.frame.size.height + 20, _officeButton.frame.size.width, _officeButton.frame.size.height);
        _officeButton.hidden = NO;
        _calculatorGroup.hidden = YES;
        _contentScroll.contentSize = CGSizeMake(320, _officeButton.frame.origin.y + _officeButton.frame.size.height + 20);
    }
    else
    {
        _calculatorGroup.frame = CGRectMake(0, _about.frame.origin.y + _about.frame.size.height + 10, 320, _calculatorGroup.frame.size.height);
        _contentScroll.contentSize = CGSizeMake(320, _calculatorGroup.frame.origin.y + _calculatorGroup.frame.size.height);
    }
}


#pragma mark - Actions

- (void)swipe:(UISwipeGestureRecognizer *)gesture
{
    if (gesture.direction == UISwipeGestureRecognizerDirectionRight && gesture.view == self.view)
    {
        [self popNavigationController];
    }
}

- (void)popNavigationController
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)toggle:(UIButton *)sender
{
    isCompanyCleaner = isCompanyCleaner ? NO : YES;
    if (isCompanyCleaner)
    {
        sender.selected = YES;
    }
    else
    {
        sender.selected = NO;
    }
}

- (int)calculator:(int)workArea
{
    int rate;
    if ([[_cleaning objectForKey:@"id"] intValue] < 5)
    {
        if (workArea <= 45)
        {
            rate = [[price objectForKey:@"45"] intValue];
        }
        else if (workArea <= 60)
        {
            rate = [[price objectForKey:@"60"] intValue];
        }
        else if (workArea <= 80)
        {
            rate = [[price objectForKey:@"80"] intValue];
        }
        else if (workArea <= 100)
        {
            rate = [[price objectForKey:@"100"] intValue];
        }
        else
        {
            rate = [[price objectForKey:@"100"] intValue];
            int additive = workArea - 100;
            rate += additive * [[price objectForKey:@"additive"] intValue];
        }
    }
    else
    {
        if (workArea <= 100)
        {
            rate = [[price objectForKey:@"100"] intValue];
        }
        else if (workArea <= 200)
        {
            rate = [[price objectForKey:@"200"] intValue];
        }
        else if (workArea <= 300)
        {
            rate = [[price objectForKey:@"300"] intValue];
        }
        else if (workArea <= 400)
        {
            rate = [[price objectForKey:@"400"] intValue];
        }
        else
        {
            rate = [[price objectForKey:@"400"] intValue];
            int additive = workArea - 100;
            rate += additive * [[price objectForKey:@"additive"] intValue];
        }
    }
    if (isCompanyCleaner)
    {
        rate += 1200;
    }
    return rate;
}

- (IBAction)calculate:(id)sender
{
    int workArea = [_workArea.text intValue];
    if (workArea == 0)
    {
        [_workArea becomeFirstResponder];
        return;
    }
    int rate = [self calculator:workArea];
    
    _caclResult.text = [NSString stringWithFormat:@"%i руб.", rate];
    if ([_workArea isFirstResponder])
    {
        [_workArea resignFirstResponder];
        [_contentScroll setContentOffset:CGPointMake(0, _contentScroll.contentSize.height - _contentScroll.frame.size.height + (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0") ? 50 : 0)) animated:YES];
        _contentScroll.scrollEnabled = YES;
    }
}

- (IBAction)add2Cart:(id)sender
{
    int workArea = [_workArea.text intValue];
    if (workArea == 0)
    {
        [_workArea becomeFirstResponder];
        return;
    }
    int rate = [self calculator:workArea];
    if ([[Cart sharedInstance] add2Cart:@{
                                          @"title": [_cleaning objectForKey:@"title"],
                                          @"price": @(rate - (isCompanyCleaner ? 1200 : 0)),
                                          @"workArea" : _workArea.text,
                                          @"ei" : @"м2"
                                          }])
    {
        /*int bValue = [[self.tabBarController.tabBar.items[2] badgeValue] intValue];
        bValue++;
        [self.tabBarController.tabBar.items[2] setBadgeValue:[NSString stringWithFormat:@"%i", bValue]];*/
    }
    if ([[_cleaning objectForKey:@"id"] isEqualToNumber:@4] || isCompanyCleaner)
    {
        [[Cart sharedInstance] add2Cart:@{@"title" : @"Проф. пылесос",
                                      @"price" : @(1200)
                                      }];
    }
}

- (IBAction)add2CartOffice:(id)sender
{
    if ([[Cart sharedInstance] add2Cart:@{@"title" : @"Вызов замерщика"}])
    {
        /*int bValue = [[self.tabBarController.tabBar.items[2] badgeValue] intValue];
        bValue++;
        [self.tabBarController.tabBar.items[2] setBadgeValue:[NSString stringWithFormat:@"%i", bValue]];*/
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    currentContentOffset = _contentScroll.contentOffset;
//    float offset;
//    
//    if (SYSTEM_VERSION_LESS_THAN(@"7.0"))
//    {
//        offset = ([UIScreen mainScreen].bounds.size.height == 568 ? 188 : 100);
//    }
//    else
//    {
//        offset = ([UIScreen mainScreen].bounds.size.height == 568 ? 252 : 164);
//    }
//    
//    [_contentScroll setContentOffset:CGPointMake(0, _calculatorGroup.frame.origin.y - offset) animated:YES];
    CGPoint offset = CGPointMake(0, _calculatorGroup.frame.origin.y - (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0") ? 64 : 0) - (IS_IPHONE_5 ? 84 : 10));
    
    [_contentScroll setContentOffset:offset animated:YES];
    _contentScroll.scrollEnabled = NO;
    
    if ([[_cleaning objectForKey:@"id"] isEqualToNumber:@4])
    {
//        _cleanerToggle.selected = YES;
        _cleanerToggle.enabled = NO;
        isCompanyCleaner = YES;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    _contentScroll.scrollEnabled = YES;
    [_contentScroll setContentOffset:CGPointMake(0, _contentScroll.contentSize.height - _contentScroll.frame.size.height + (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0") ? 64 : 0)) animated:YES];
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    int iValue;
    if (string.length != 0 && ![[NSScanner scannerWithString:string] scanInt:&iValue])
    {
        return NO;
    }
    return YES;
}

@end
