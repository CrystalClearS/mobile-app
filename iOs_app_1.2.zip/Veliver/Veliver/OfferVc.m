//
//  OfferVc.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 02.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "OfferVc.h"
#import "NSDictionary+QueryString.h"
#import "Cart.h"

@interface OfferVc () <UIAlertViewDelegate>
{
    NSArray *items_;
    int sum;
    Cart *cart_;
    NSUserDefaults *userDefaults_;
    BOOL isHistoryOrder;
}
@end

@implementation OfferVc

- (id)initWithItems:(NSArray *)items andSumm:(int)summ
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        isHistoryOrder = NO;
        items_ = items;
        sum = summ;
        cart_ = [Cart sharedInstance];
        userDefaults_ = [NSUserDefaults standardUserDefaults];
    }
    return self;
}
-(id)initWithItems:(NSArray *)items andSumm:(int)summ fromHistoryRecords:(NSDictionary*)dictinary
{
    if (self) {
        isHistoryOrder = YES;
        items_ = items;
        sum = summ;
        cart_ = [Cart sharedInstance];
        userDefaults_ = [NSUserDefaults standardUserDefaults];
        _historyRecords = [[NSDictionary alloc]initWithDictionary:[dictinary objectForKey:@"client"]];
    }
    return self;

}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title.png"]];
    _summ.text = [NSString stringWithFormat:@"%i руб.", (int)(sum - sum*0.1)];
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    
    toolbar.items = @[
                      [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                      [[UIBarButtonItem alloc] initWithTitle:@"Готово" style:UIBarButtonItemStyleDone target:self action:@selector(hidePiker)]
                      ];
    
    _date.inputView = _datePicker;
    _date.inputAccessoryView = toolbar;
    
    _time.inputView = _timePicker;
    _time.inputAccessoryView = toolbar;
    _phone.inputAccessoryView = toolbar;
    
    [self configureFields];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

- (void)configureFields
{
    _fio.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 9, 35)];
    _fio.leftViewMode = UITextFieldViewModeAlways;
    
    _address.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 9, 35)];
    _address.leftViewMode = UITextFieldViewModeAlways;
    
    _date.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 9, 35)];
    _date.leftViewMode = UITextFieldViewModeAlways;
    
    _time.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 9, 35)];
    _time.leftViewMode = UITextFieldViewModeAlways;
    
    _phone.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 9, 35)];
    _phone.leftViewMode = UITextFieldViewModeAlways;
    if([_historyRecords count]>0)
    {
        _fio.text = [_historyRecords objectForKey:@"fio"];
        _address.text = [_historyRecords objectForKey:@"address"];
        _phone.text = [_historyRecords objectForKey:@"phone"];
        
    }else
    {
        _fio.text = [userDefaults_ objectForKey:@"fio"];
        _address.text = [userDefaults_ objectForKey:@"address"];
        //_date.text = [userDefaults_ objectForKey:@"date"];
        //_time.text = [userDefaults_ objectForKey:@"time"];
        _phone.text = [userDefaults_ objectForKey:@"phone"];
    }
}

- (void)hidePiker
{
    if ([_date isFirstResponder])
    {
        [_date resignFirstResponder];
        [self dateChange:_datePicker];
    }
    else if ([_time isFirstResponder])
    {
        [_time resignFirstResponder];
        [self timeChange:_timePicker];
    }
    else
    {
        [_phone resignFirstResponder];
        if (!IS_IPHONE_5)
            [_content setContentOffset:CGPointMake(0, SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0") ? -64 : 0) animated:YES];
    }
}

#pragma mark UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
//    textField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 9, 35)];
//    textField.leftViewMode = UITextFieldViewModeAlways;
    if (!IS_IPHONE_5 && textField == _phone)
    {
        [_content setContentOffset:CGPointMake(0, 80) animated:YES];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

- (IBAction)send:(UIButton *)sender
{
    if (_fio.text.length == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка!" message:@"Пожалуйста, заполните ФИО" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        return;
    }
    if (_address.text.length == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка!" message:@"Пожалуйста, заполните андрес" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        return;
    }
    if (_date.text.length == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка!" message:@"Пожалуйста, укажите дату" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        return;
    }
    if (_time.text.length == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка!" message:@"Пожалуйста, укажите время" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        return;
    }
    if (_phone.text.length == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Ошибка!" message:@"Пожалуйста, укажите телефон" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        return;
    }
    
    NSMutableString *message = [NSMutableString new];
    [message appendString:@"Корзина:\n-------------------------------------------\n"];
    int i = 0;
    for (id item in items_) {
        i++;
        if ([item objectForKey:@"work"] != nil)
        {
            [message appendFormat:@"%i. %@ %@ руб.\n", i,
             [item objectForKey:@"title"],
             [[item objectForKey:@"price"] stringValue]
             ];
            for (id w in [item objectForKey:@"work"])
            {
                [message appendFormat:@"   - %@: %@ %@\n",
                 [w objectForKey:@"title"],
                 [[w objectForKey:@"workArea"] stringValue],
                 [w objectForKey:@"ie"]
                 ];
            }
        }
        else
        {
            [message appendFormat:@"%i. %@ %@ руб. (%@ %@)\n", i,
             [item objectForKey:@"title"],
             [item objectForKey:@"price"] ? [[item objectForKey:@"price"] stringValue] : @"0",
             [item objectForKey:@"workArea"] ? [item objectForKey:@"workArea"] : @"-",
             [item objectForKey:@"ei"] ? [item objectForKey:@"ei"] : @"-"];
        }
    }
    [message appendFormat:@"-------------------------------------------\nОбщая сумма: %i руб.\n", sum];
    [message appendFormat:@"Общая сумма с учетом скидки: %i руб.\n", (int)(sum - sum*0.1)];
    
    [message appendString:@"\nКлиент:\n-------------------------------------------\n"];
    
    [message appendFormat:@"ФИО: %@\nАдрес: %@\nДата: %@\nВремя: %@\nТелефон: %@",
    _fio.text,
    _address.text,
    _date.text,
    _time.text,
     _phone.text];
    
    
    sender.enabled = NO;
    NSDictionary *params = [NSDictionary dictionaryWithObject:message forKey:@"message"];
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"iosmail.php%@", [params queryString]] relativeToURL:[NSURL URLWithString:@"http://www.veliver.ru/"]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    [NSURLConnection sendAsynchronousRequest:request queue:[[NSOperationQueue alloc] init] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            sender.enabled = YES;
            if (connectionError == nil)
            {
                [userDefaults_ setObject:_fio.text forKey:@"fio"];
                [userDefaults_ setObject:_address.text forKey:@"address"];
                [userDefaults_ setObject:_date.text forKey:@"date"];
                [userDefaults_ setObject:_time.text forKey:@"time"];
                [userDefaults_ setObject:_phone.text forKey:@"phone"];
                [userDefaults_ synchronize];
                
                //if (!isHistoryOrder) {
                [cart_ saveCart:items_ client:@{
                                                @"fio" : _fio.text,
                                                @"address" : _address.text,
                                                @"date" : _date.text,
                                                @"time" : _time.text,
                                                @"phone" : _phone.text
                                                } summa:[NSString stringWithFormat:@"%i", sum]];
                //}
                [[[UIAlertView alloc] initWithTitle:@"Спасибо!"
                                            message:@"Ваша заявка отправлена.\nМы обязательно позвоним Вам для подтверждения заказа!"
                                           delegate:self
                                  cancelButtonTitle:@"Ok"
                                  otherButtonTitles:nil] show];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"Cart"];
                [cart_ clearCart];
            }
            else
            {
                [[[UIAlertView alloc] initWithTitle:@"Ошибка!"
                                            message:@"Что-то пошло не так, пожалуйста, попробуйте повторить позже"
                                           delegate:nil
                                  cancelButtonTitle:@"Ok"
                                  otherButtonTitles:nil] show];
            }
        });
    }];


    
}




- (IBAction)timeChange:(UIDatePicker *)sender
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"HH:mm"];
    _time.text = [formatter stringFromDate:sender.date];
}

- (IBAction)dateChange:(UIDatePicker *)sender
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd.MM.yyyy"];
    _date.text = [formatter stringFromDate:sender.date];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (isHistoryOrder) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

@end
