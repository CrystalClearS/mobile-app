//
//  HistoryCell.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 09.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *backgournd;
@property (weak, nonatomic) IBOutlet UILabel *date;
@property (weak, nonatomic) IBOutlet UILabel *price;

@end
