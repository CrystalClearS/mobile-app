//
//  Cart.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 22.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Cart : NSObject

+ (Cart *)sharedInstance;

@property (nonatomic) NSMutableArray *items;

- (BOOL)add2Cart:(NSDictionary *)item;
- (BOOL)addItems2Cart:(NSArray *)items;
- (void)deleteItem:(NSDictionary *)item;
- (void)deleteItemFromHistory:(NSDictionary *)item;
- (void)clearCart;
- (void)saveCart:(NSArray *)cart client:(NSDictionary *)client summa:(NSString *)summa;
- (NSArray *)loadOrderHistory;

@end
