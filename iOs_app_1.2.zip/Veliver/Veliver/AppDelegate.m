//
//  AppDelegate.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

#import "AppDelegate.h"
#import "ViewController.h"
#import "AdditionalServicesVc.h"
#import "WindowVc.h"
#import "CartVc.h"
#import "Cart.h"
#import "ContactsVc.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    UIImageView *defaultImage;
    if (IS_IPHONE_5)
    {
        defaultImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Default-568h"]];
    }
    else
    {
        defaultImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Default"]];
    }
    
    [self.window addSubview:defaultImage];
    
    
    
    self.tabBarController = [[UITabBarController alloc] init];
    
    self.cleaningViewController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
    UINavigationController *cleaningNavigationController = [[UINavigationController alloc] initWithRootViewController:self.cleaningViewController];
    
    self.windowVc = [[WindowVc alloc] initWithNibName:nil bundle:nil];
    UINavigationController *windowNc = [[UINavigationController alloc] initWithRootViewController:self.windowVc];
    
    self.additionalServicesVc = [[AdditionalServicesVc alloc] initWithNibName:nil bundle:nil];
    UINavigationController *additionalServicesNc = [[UINavigationController alloc] initWithRootViewController:self.additionalServicesVc];
    
    self.cartVc = [[CartVc alloc] initWithNibName:nil bundle:nil];
    UINavigationController *cartNc = [[UINavigationController alloc] initWithRootViewController:self.cartVc];
    
    self.contactsVc = [[ContactsVc alloc] initWithNibName:nil bundle:nil];
    UINavigationController *contactsNc = [[UINavigationController alloc] initWithRootViewController:self.contactsVc];
    
    [self.tabBarController addChildViewController:cleaningNavigationController];
    [self.tabBarController addChildViewController:windowNc];
    [self.tabBarController addChildViewController:additionalServicesNc];
    [self.tabBarController addChildViewController:contactsNc];
    [self.tabBarController addChildViewController:cartNc];
    
    
    
    [self configureAppearanceAPI];
    
    self.window.rootViewController = self.tabBarController;
    [self.window makeKeyAndVisible];
    
    [self.window bringSubviewToFront:defaultImage];
    [application setStatusBarHidden:YES];
    
    [UIView animateWithDuration:0.5 delay:1.6 options:UIViewAnimationOptionCurveEaseOut animations:^{
        defaultImage.alpha = 0;
        [application setStatusBarHidden:NO];
    } completion:^(BOOL finished) {
        [defaultImage removeFromSuperview];
    }];
    
    if ([Cart sharedInstance].items.count > 0)
        [self.tabBarController.tabBar.items[4] setBadgeValue:[NSString stringWithFormat:@"%lu", (unsigned long)[Cart sharedInstance].items.count]];
    else
    {
        [self.tabBarController.tabBar.items[4] setBadgeValue:nil];
    }
    
    return YES;
}

- (void)configureAppearanceAPI
{
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        [[UINavigationBar appearance] setBarTintColor:[UIColor colorWithRed:188.0/255.0 green:75.0/255.0 blue:129.0/255.0 alpha:1]];
        [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
        [[UITabBar appearance] setBarTintColor:[UIColor colorWithRed:188.0/255.0 green:75.0/255.0 blue:129.0/255.0 alpha:1]];
        
        [[UITabBar appearance] setTintColor:[UIColor colorWithRed:255.0/255.0 green:0.0/255.0 blue:125.0/255.0 alpha:1.0]];
        
        [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"Helvetica-Bold" size:18], NSFontAttributeName, [UIColor whiteColor], NSForegroundColorAttributeName,nil]];
    }
    else
    {
        [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:160.0/255.0 green:50.0/255.0 blue:100.0/255.0 alpha:1]];
        [[UITabBar appearance] setSelectionIndicatorImage:[[UIImage alloc] init]];
        [[UITabBar appearance] setSelectedImageTintColor:[UIColor colorWithRed:255.0/255.0 green:0.0/255.0 blue:125.0/255.0 alpha:1.0]];
        [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"Helvetica-Bold" size:18], NSFontAttributeName,nil]];
    }
    
    
    
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                       [UIColor whiteColor],
                                                       NSForegroundColorAttributeName, nil]
                                             forState:UIControlStateNormal];
    
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                       [UIColor colorWithRed:255.0/255.0 green:0.0/255.0 blue:125.0/255.0 alpha:1.0],
                                                       NSForegroundColorAttributeName, nil]
                                             forState:UIControlStateSelected];
    
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
