//
//  CartVc.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 22.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Cart;
@class HistoryController;

@interface CartVc : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UITableView *historyTable;
@property (nonatomic) NSMutableArray *items;
@property (weak, nonatomic) IBOutlet UIView *resultGroup;
@property (weak, nonatomic) IBOutlet UILabel *result;
@property (weak, nonatomic) IBOutlet UILabel *empty;
@property (weak, nonatomic) IBOutlet UIScrollView *content;
@property (weak, nonatomic) IBOutlet UIView *historyGroup;

@property (strong, nonatomic) IBOutlet HistoryController *historyController;
- (IBAction)offer:(id)sender;

@end
