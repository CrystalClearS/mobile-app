//
//  AdditionalServicesVc.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "AdditionalServicesVc.h"
#import "AdditionalCell.h"

@interface AdditionalServicesVc ()
{
    CGPoint currentContentOffset;
    NSMutableArray *expandedPaths;
    NSMutableArray *calculateSumms;
    BOOL isKeyboardSown;
}
@end

@implementation AdditionalServicesVc

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Доп.услуги";
        
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:@"Доп.услуги" image:[UIImage imageNamed:@"additional.png"] tag:2];
        self.tabBarItem = item;
        
        NSString *path = [[NSBundle mainBundle]pathForResource:@"additional" ofType:@"plist"];
        _additionalList = [NSArray arrayWithContentsOfFile:path];
        expandedPaths = [NSMutableArray new];
        calculateSumms = [NSMutableArray new];
        for (__unused id i in _additionalList) {
            [calculateSumms addObject:[NSMutableDictionary new]];
        }
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title.png"]];
    [self.table registerNib:[UINib nibWithNibName:@"AdditionalCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"AdditionalCell"];
    self.table.showsVerticalScrollIndicator = NO;
    self.table.clipsToBounds = NO;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShowNotification:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHideNotification:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)keyboardWillShowNotification:(NSNotification *)note
{
    if (isKeyboardSown) { return; }
    NSDictionary *userInfo = note.userInfo;
    CGRect keyboardSize = ((NSValue *)userInfo[UIKeyboardFrameEndUserInfoKey]).CGRectValue;
    double animationDuration = ((NSNumber *)userInfo[UIKeyboardAnimationDurationUserInfoKey]).doubleValue;
    UIViewAnimationCurve curveAnimation = ((NSNumber *)userInfo[UIKeyboardAnimationCurveUserInfoKey]).integerValue;
    
    [UIView animateWithDuration:animationDuration delay:0 options:curveAnimation << 16 animations:^{
        CGRect frame = _table.frame;
        frame.size.height -= keyboardSize.size.height + 4;
        _table.frame = frame;
    } completion:^(BOOL finished) {
        isKeyboardSown = YES;
    }];
}

- (void)keyboardWillHideNotification:(NSNotification *)note
{
    if (!isKeyboardSown) { return; }
    NSDictionary *userInfo = note.userInfo;
    CGRect keyboardSize = ((NSValue *)userInfo[UIKeyboardFrameEndUserInfoKey]).CGRectValue;
    double animationDuration = ((NSNumber *)userInfo[UIKeyboardAnimationDurationUserInfoKey]).doubleValue;
    UIViewAnimationCurve curveAnimation = ((NSNumber *)userInfo[UIKeyboardAnimationCurveUserInfoKey]).integerValue;
    
    [UIView animateWithDuration:animationDuration delay:0 options:curveAnimation << 16 animations:^{
        CGRect frame = _table.frame;
        frame.size.height += keyboardSize.size.height + 4;
        _table.frame = frame;
    } completion:^(BOOL finished) {
        isKeyboardSown = NO;
    }];
}

#pragma mark - Helpers

- (void)changeHeight:(NSIndexPath *)indexPath
{
    AdditionalCell *cell = (AdditionalCell*)[_table cellForRowAtIndexPath:indexPath];
    
    [calculateSumms[indexPath.row] setObject:cell.price.text forKey:@"summ"];
    [calculateSumms[indexPath.row] setObject:cell.filed.text forKey:@"workArea"];
    [expandedPaths addObject:indexPath];
    
    [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        cell.separator.center = CGPointMake(cell.separator.center.x, 128);
    } completion:^(BOOL finished) {
        
    }];
    
    [_table reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([expandedPaths containsObject:indexPath])
        return 130;
    return 111;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _additionalList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"AdditionalCell";
//    AdditionalCell *cell = (AdditionalCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    AdditionalCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    cell.delegate = self;
    cell.adittional = _additionalList[indexPath.row];
    cell.indexPath = indexPath;
    cell.title.text = [_additionalList[indexPath.row] objectForKey:@"title"];
    cell.filed.text = [calculateSumms[indexPath.row] objectForKey:@"workArea"];
    cell.price.text = [calculateSumms[indexPath.row] objectForKey:@"summ"];
    if ([expandedPaths containsObject:indexPath])
        cell.price.hidden = NO;
    else
        cell.price.hidden = YES;
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    currentContentOffset = _table.contentOffset;
    float offset;
    
    if (SYSTEM_VERSION_LESS_THAN(@"7.0"))
    {
        offset = textField.superview.superview.frame.origin.y;
    }
    else
    {
        offset = textField.superview.superview.superview.frame.origin.y-66;
    }
    [_table setContentOffset:CGPointMake(0, offset) animated:YES];
    _table.scrollEnabled = NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [_table setContentOffset:currentContentOffset animated:YES];
    _table.scrollEnabled = YES;
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    _table.scrollEnabled = YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    int iValue;
    if (string.length != 0 && ![[NSScanner scannerWithString:string] scanInt:&iValue])
    {
        return NO;
    }
    return YES;
}

@end
