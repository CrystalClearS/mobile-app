//
//  AdditionalCell.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 22.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AdditionalServicesVc;

@interface AdditionalCell : UITableViewCell <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *filed;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UIButton *calculate;
@property (weak, nonatomic) IBOutlet UIButton *add2Cart;
@property (nonatomic) NSDictionary *adittional;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (nonatomic) NSIndexPath *indexPath;
@property (nonatomic) AdditionalServicesVc *delegate;
@property (weak, nonatomic) IBOutlet UIImageView *separator;

- (IBAction)calc:(id)sender;
- (IBAction)addCart:(id)sender;

@end
