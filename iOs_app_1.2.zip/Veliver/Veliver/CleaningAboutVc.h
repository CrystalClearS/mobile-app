//
//  CleaningAboutVc.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CleaningAboutVc : UIViewController <UITextFieldDelegate>

@property (nonatomic) NSDictionary *cleaning;
@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UIScrollView *contentScroll;
@property (weak, nonatomic) IBOutlet UILabel *about;
@property (weak, nonatomic) IBOutlet UIView *calculatorGroup;
@property (weak, nonatomic) IBOutlet UITextField *workArea;
@property (weak, nonatomic) IBOutlet UIButton *inCart;
@property (weak, nonatomic) IBOutlet UIButton *calc;
@property (weak, nonatomic) IBOutlet UILabel *caclResult;
@property (weak, nonatomic) IBOutlet UIButton *officeButton;
@property (weak, nonatomic) IBOutlet UIButton *cleanerToggle;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil cleaning:(NSDictionary *)cleaning;
- (IBAction)toggle:(UIButton *)sender;
- (IBAction)calculate:(id)sender;
- (IBAction)add2Cart:(id)sender;
- (IBAction)add2CartOffice:(id)sender;


@end
