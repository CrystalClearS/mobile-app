//
//  AdditionalServicesVc.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AdditionalServicesVc : UIViewController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITableView *table;
@property (nonatomic) NSArray *additionalList;

- (void)changeHeight:(NSIndexPath *)indexPath;

@end
