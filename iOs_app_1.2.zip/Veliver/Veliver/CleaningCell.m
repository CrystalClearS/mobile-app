//
//  CleaningCell.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "CleaningCell.h"

@implementation CleaningCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {

    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

@end
