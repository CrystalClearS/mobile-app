//
//  ContactsVc.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 02.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface ContactsVc : UIViewController <UITextViewDelegate, MFMailComposeViewControllerDelegate>

@property (weak, nonatomic) IBOutlet UIScrollView *content;
@property (weak, nonatomic) IBOutlet UITextView *textView;
- (IBAction)sendReview:(id)sender;

@end
