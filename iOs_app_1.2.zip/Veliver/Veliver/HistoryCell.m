//
//  HistoryCell.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 09.10.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "HistoryCell.h"

@implementation HistoryCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    _backgournd.highlighted = selected;
    _price.textColor = selected ? [UIColor whiteColor] : [UIColor colorWithRed:255.0/255.0 green:147.0/255.0 blue:198.0/255.0 alpha:1.0];
}

@end
