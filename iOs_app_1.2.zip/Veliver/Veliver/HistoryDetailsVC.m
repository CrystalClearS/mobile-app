//
//  HistoryDetailsVC.m
//  Veliver
//
//  Created by Aleksey Maltsev on 13.12.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "HistoryDetailsVC.h"
#import "CartCell.h"
#import "Cart.h"
#import "OfferVc.h"
@interface HistoryDetailsVC ()
{
    BOOL hasOffice;
    int sum;

}
@end

@implementation HistoryDetailsVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (IBAction)removeButtonTouch:(id)sender {
    
    [[Cart sharedInstance] deleteItemFromHistory:_sourceRecord];
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)repeatOrderButtonTouch:(id)sender {
    [[Cart sharedInstance] addItems2Cart:[_items copy]];
    [self.navigationController popViewControllerAnimated:true];
    /*OfferVc *vc = [[OfferVc alloc]initWithItems:_items andSumm:sum fromHistoryRecords:_sourceRecord];
    [self.navigationController pushViewController:vc animated:YES];*/
}

- (id)initWithItemes:(NSDictionary *)itemsArrary
{
    if(self= [super init])
    {
        _items = [[NSMutableArray alloc]initWithArray:[itemsArrary objectForKey:@"cart"]];
        _sourceRecord = [[NSDictionary alloc]initWithDictionary:itemsArrary];
    }
    return self;
}
-(void)calc
{
    sum = 0;
    for (NSDictionary *item in _items) {
        if ([item objectForKey:@"price"])
            sum += [[item objectForKey:@"price"] intValue];
        else
        {
            hasOffice = YES;
        }
    }
    
    if (_items.count > 0){
    }
        //[self.tabBarController.tabBar.items[4] setBadgeValue:[NSString stringWithFormat:@"%i", _items.count]];
    else
    {
        //[self.tabBarController.tabBar.items[4] setBadgeValue:nil];
        hasOffice = NO;
    }
    
    if (sum != 0 || hasOffice)
    {
        _result.text = [NSString stringWithFormat:@"%i руб.", (int)(sum - sum*0.1f)];
        _resultGroup.hidden = NO;
      //  _empty.hidden = YES;
    }
    else
    {
      //  _empty.hidden = NO;
        _resultGroup.hidden = YES;
       // _empty.frame = CGRectMake(0, IS_IPHONE_5 ? 144 : 100, 320, _empty.frame.size.height);
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.layer.contents = (id)[UIImage imageNamed:IS_IPHONE_5 ? @"background-568h.png" : @"background.png"].CGImage;
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title.png"]];
    
    if (_items.count > 0){
    }
        //[self.tabBarController.tabBar.items[4] setBadgeValue:[NSString stringWithFormat:@"%i", _items.count]];
    else
    {
        //[self.tabBarController.tabBar.items[4] setBadgeValue:nil];
        hasOffice = NO;
    }
   
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self calc];
    _table.frame = CGRectMake(0, _table.frame.origin.y, _table.frame.size.width, _items.count *52 + (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0") ? 0.0 : 0.0));
    
    _resultGroup.frame = CGRectMake(0, _table.frame.origin.y + _table.frame.size.height, 320,  _resultGroup.frame.size.height);
    _content.contentSize = CGSizeMake(320, _resultGroup.frame.origin.y + _resultGroup.frame.size.height);
    _resultGroup.hidden = NO;
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"CartCell";
    CartCell *cell = (CartCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
    {
        NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:cellIdentifier owner:self options:nil];
        cell = [nibs objectAtIndex:0];
    }
    cell.title.text = [_items[indexPath.row] objectForKey:@"title"];
    
    if ([_items[indexPath.row] objectForKey:@"workArea"] != nil)
    {
        cell.count.text = [NSString stringWithFormat:@"(%@ %@)",
                           [_items[indexPath.row] objectForKey:@"workArea"],
                           [_items[indexPath.row] objectForKey:@"ei"]];
        cell.count.hidden = NO;
        cell.title.frame = CGRectMake(cell.title.frame.origin.x, 6, cell.title.frame.size.width, cell.title.frame.size.height);
    }
    else
    {
        cell.title.frame = CGRectMake(cell.title.frame.origin.x, 13, cell.title.frame.size.width, cell.title.frame.size.height);
        cell.count.hidden = YES;
    }
    if ([_items[indexPath.row] objectForKey:@"price"] != nil)
    {
        cell.price.text = [NSString stringWithFormat:@"%@ р.", [[_items[indexPath.row] objectForKey:@"price"] stringValue]];
        cell.price.hidden = NO;
    }
    else
    {
        cell.price.hidden = YES;
    }
    cell.item = _items[indexPath.row];
    cell.closeButton.hidden = YES;
    [cell.price setFrame:CGRectMake(218, cell.price.frame.origin.y, cell.price.frame.size.width, cell.price.frame.size.height)];
    return cell;
}
@end
