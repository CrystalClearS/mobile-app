//
//  AdditionalCell.m
//  Veliver
//
//  Created by IVAN CHIRKOV on 22.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import "AdditionalCell.h"
#import "AdditionalServicesVc.h"
#import "Cart.h"

@implementation AdditionalCell
{
    CGPoint currentContentOffset;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib {
    self.filed.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 4, 32)];
    self.filed.leftViewMode = UITextFieldViewModeAlways;
    self.filed.rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, 32)];
    self.filed.rightViewMode = UITextFieldViewModeAlways;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}


- (IBAction)calc:(id)sender
{
    if (_filed.text.length == 0)
    {
        _filed.text = 0;
        return;
    }
    int rate = [[_adittional objectForKey:@"price"] intValue];
    _price.text = [NSString stringWithFormat:@"%i руб.", [_filed.text intValue] * rate];
    _price.hidden = NO;
    [_delegate changeHeight:_indexPath];
    [_filed resignFirstResponder];
}

- (IBAction)addCart:(id)sender
{
    if (_filed.text.length == 0)
    {
        [_filed becomeFirstResponder];
    }
    else
    {
        int rate = [[_adittional objectForKey:@"price"] intValue];
        int sum = [_filed.text intValue] * rate;
        NSString *title = [[[_adittional objectForKey:@"title"] stringByReplacingOccurrencesOfString:@" (м2)" withString:@""] stringByReplacingOccurrencesOfString:@" (шт.)" withString:@""];
        
        [[Cart sharedInstance] add2Cart:@{
                                          @"title" : title,
                                          @"price" : @(sum),
                                          @"workArea" : _filed.text,
                                          @"ei" : [_adittional objectForKey:@"ei"]
                                          }];
        int itemId = [[_adittional objectForKey:@"id"] intValue];
        if (itemId == 101 || itemId == 102 || itemId == 103 || itemId == 104)
        {
            [[Cart sharedInstance] add2Cart:@{@"title" : @"Проф. пылесос",
                                              @"price" : @(1200)
                                              }];
        }
        [_filed resignFirstResponder];
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    int iValue;
    if (string.length != 0 && ![[NSScanner scannerWithString:string] scanInt:&iValue])
    {
        return NO;
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
