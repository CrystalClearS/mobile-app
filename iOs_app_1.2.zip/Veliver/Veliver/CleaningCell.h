//
//  CleaningCell.h
//  Veliver
//
//  Created by IVAN CHIRKOV on 07.09.13.
//  Copyright (c) 2013 IVAN CHIRKOV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CleaningCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *separator;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UIImageView *ico;

@end
