//
//  NSDictionary+QueryString.h
//  LookMedBook
//
//  Created by IVAN CHIRKOV on 17.09.13.
//  Copyright (c) 2013 65gb. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (QueryString)

- (NSString *)queryString;

@end
